package com.example.alarmclock;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    static final int ALARM_REQ_CODE=100;
    private boolean isAlarmSet = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        findViewById(R.id.b1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                showTimePickerDialog();
            }
        });
        findViewById(R.id.b2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dismissAlarm();
            }
        });
    }
        private void showTimePickerDialog() {
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker timePicker, int hourOfDay, int minute) {
                            // Convert the selected time to seconds.
                            int timeInSeconds = (hourOfDay * 3600) + (minute * 60);
                            setAlarm(timeInSeconds);
                        }
                    }, Calendar.getInstance().get(Calendar.HOUR_OF_DAY),
                    Calendar.getInstance().get(Calendar.MINUTE), false);

            timePickerDialog.show();
        }
        private void setAlarm(int timeInSeconds) {
            AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
            long triggerTime =  (timeInSeconds * 1000);

            Intent intent = new Intent(MainActivity.this, MyReceiver.class);
            intent.setAction("android.intent.action.ALARM_TRIGGERED");

            PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, ALARM_REQ_CODE, intent, PendingIntent.FLAG_UPDATE_CURRENT);

            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pi);
            Toast.makeText(MainActivity.this, "Alarm has been set!", Toast.LENGTH_SHORT).show();

            isAlarmSet = true;
        }
    private void dismissAlarm() {
        if (isAlarmSet) {
            MyReceiver.stopAlarm();
            isAlarmSet = false;
            Toast.makeText(MainActivity.this, "Alarm dismissed!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MainActivity.this, "No alarm to dismiss.", Toast.LENGTH_SHORT).show();
        }
    }


}

